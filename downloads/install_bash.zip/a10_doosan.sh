# 1) 통합 bringup 레포
git clone -b jazzy https://github.com/ROKEY-SPARK/m0609_rg2_integration ~/m0609_rg2_integration

# 2) DSR 에뮬레이터 이미지
docker pull doosanrobot/dsr_emulator:3.0.1

# 3) DSR 전용 apt 의존
sudo apt-get install -y ros-jazzy-velocity-controllers ros-jazzy-eigen3-cmake-module

# 4) 오디오 시스템 라이브러리
sudo apt install -y portaudio19-dev libsndfile1

# 5) 두산 스택 워크스페이스
mkdir -p ~/cobot2_ws/src
git clone https://github.com/ROKEY-SPARK/doosan-robot2_jazzy.git ~/cobot2_ws/src/doosan-robot2
ln -sfn ~/m0609_rg2_integration/src/m0609_rg2_bringup ~/cobot2_ws/src/m0609_rg2_bringup
git clone https://github.com/ABC-iRobotics/onrobot-ros2 ~/cobot2_ws/src/onrobot-ros2
git -C ~/cobot2_ws/src/onrobot-ros2 checkout c6e390313e831a2e54a0ad5894b2911cc360a16a

# 6) DSR 전용 apt 의존 + Calibration 런타임 Python
sudo apt-get update
sudo apt-get install -y \
  ros-jazzy-velocity-controllers ros-jazzy-eigen3-cmake-module \
  python3-numpy python3-scipy python3-pymodbus
  
# 7) colcon 빌드
source /opt/ros/jazzy/setup.bash
cd ~/cobot2_ws
rosdep update
rosdep install --from-paths src --ignore-src --rosdistro jazzy \
  --skip-keys="librealsense2 message_generation message_runtime" -y
colcon build

# 검증
source ~/cobot2_ws/install/setup.bash
ros2 pkg list | grep -E "m0609_rg2_bringup|onrobot_rg_control|dsr_bringup2"


